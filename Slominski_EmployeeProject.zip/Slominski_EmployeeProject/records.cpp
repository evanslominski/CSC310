#include <iostream>
#include <ostream>
#include <fstream>
#include <string.h>
#include <sys/stat.h>
#include "records.h"
#include "customErrorClass.h"

using namespace std;

/*
**	Author: Evan Slominski
**	Function Purpose: call private functions and validate file entered
**		
**	Function Output: none
**	Side Effects: none
*/
void C_Binary::readInSortAndWriteSortedFile( int argc, char *argv[] ) {
    bool retValue;
    string fileName;

    //Perform some exception handling
    retValue = p_validateFile(argc, argv);

    //call private function
    p_readInSortAndWriteSortedFile( argv[1] );
}

/*
**	Author: Evan Slominski
**	Function Purpose: prompt user for action and call private functions
**		
**	Function Output: none
**	Side Effects: none
*/
void C_Binary::promptUser() {
    
    int userChoice;
    int flag = 0;

    topMenu:
    system("clear");
    while( flag == 0 ) {
        cout << "Menu Options for Searching the Sorted File" << endl;
        cout << "    1. Get employee name" << endl;
        cout << "    2. Update employee name" << endl;
        cout << "    3. Delete employee" << endl;
        cout << "    4. Print employees in a given range" << endl;
        cout << "    5. Exit program" << endl;
        cin >> userChoice;

        switch (userChoice)
        {
        case 1:
            system("clear");
            p_getEmployeeName( this->globalSortedFileName );
            cout << endl;
            break;
        case 2:
            p_changeEmployeeName( this->globalSortedFileName );
            break;
        case 3:
            p_deleteEmployee( this->globalSortedFileName);
            break;
        case 4:
            p_listEmployeesByRange( this->globalSortedFileName );
            break;
        case 5:
            cout << "Exiting..." << endl;
            flag = 1;
        default:
            cout << "Enter a valid menu choice" << endl;
            goto topMenu;
            break;
        }
    }   
}
//**********PRIVATE**************
//*******************************

/*
**	Author: Evan Slominski
**	Function Purpose: validate the file
**		
**	Function Output: none
**	Side Effects: can throw an exception
*/
bool C_Binary::p_validateFile(int argc, char *argv[]) {
    int error = 0;
    bool retValue = false;
    string errorString;
    struct stat fileValidation;
    char * file = argv[1];

    //check if file exists
    if( 1 >= argc || 3 <= argc) {
        string firstArg = argv[0];
        throw MyException("USAGE: " + firstArg + " [FILENAME]");
        cout<<"exiting..."<<endl;
    } else {
        error = stat(file, &fileValidation);

        if( 0 != error ) {
            errorString = strerror(errno);
            errorString += ": ";
            errorString += argv[1];
            throw runtime_error(errorString);
        }

        if(fileValidation.st_size == 0) {
            errorString = "File is empty: ";
            errorString += argv[1];
            throw runtime_error(errorString);
        }

        retValue = true;
    }
    return retValue;
}

/*
**	Author: Evan Slominski
**	Function Purpose: read in, sort, write sorted binary, create index, validate file
**		
**	Function Output: none
**	Side Effects: none
*/
void C_Binary::p_readInSortAndWriteSortedFile( string fileName) {
    //set globalFileName
    this->globalFileName = fileName;

    //open unsorted binary for sorting
    fstream inputUnsortedFile;
    inputUnsortedFile.open( fileName, ios::in|ios::binary);

    //get the size of the file 
    int fileStringLength = 0;
    struct stat sb;
    fileStringLength = fileName.length();
    char file[ fileStringLength + 1];
    strncpy( file, fileName.c_str(), sizeof(fileName));
    stat( file, &sb);
    int sizeInBytes = sb.st_size;
    int structsNeeded = ((sizeInBytes/38)+100);

    //allocate memory
    employeeData *array = new employeeData[structsNeeded];

    //read in unsorted binary to structs
    string inputData;
    employeeData employee;
    int inputNum = 0;

    inputUnsortedFile.read( (char*)&array[inputNum], sizeof(char)*38);

    while(!inputUnsortedFile.eof()) {
  
        inputNum++;
        inputUnsortedFile.read( (char*)&array[inputNum], (sizeof(char)*38));
    }
    inputUnsortedFile.close();

    //sort the struct array with quicksort
    p_quickSort( array, 0, inputNum-1 );

    //write the sorted array to a file 
    string sortedFileName = "Sorted_" + fileName;
    this->globalSortedFileName = sortedFileName;
    fstream sortedBinaryFile;
    sortedBinaryFile.open(sortedFileName, ios::out|ios::binary);
    int a = 0;
    while(a < inputNum) {
        sortedBinaryFile.write( (char*)&array[a], (sizeof(char)*38));
              if(array[inputNum].id == 45731) {
            cout<< "FOUND IT"<< endl;
            cout<< "department num: " << array[inputNum].department << endl;
        }
        a++;
    }
    sortedBinaryFile.close();

    //indexTheArray
    p_indexArray( sortedFileName, array );
}

/*
**	Author: Evan Slominski
**	Function Purpose: sort the data quickly
**		
**	Function Output: none
**	Side Effects: none
*/
void C_Binary::p_quickSort(employeeData arr[], int low, int high)
{
    if (low < high)
    {
        /* pi is partitioning index, arr[p] is now
        at right place */
        int pi = p_partition(arr, low, high);
 
        // Separately sort elements before
        // partition and after partition
        p_quickSort(arr, low, pi - 1);
        p_quickSort(arr, pi + 1, high);
    }
}

/*
**	Author: Evan Slominski
**	Function Purpose: helper function for quicksort
**		
**	Function Output: none
**	Side Effects: none
*/
int C_Binary::p_partition (employeeData arr[], int low, int high)
{
    int pivot = arr[high].department; // pivot
    int i = (low - 1); // Index of smaller element and indicates the right position of pivot found so far
 
    for (int j = low; j <= high - 1; j++)
    {
        // If current element is smaller than the pivot
        if (arr[j].department < pivot)
        {
            i++; // increment index of smaller element
            p_swap(&arr[i], &arr[j]);
         
        }
    }
    p_swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}

/*
**	Author: Evan Slominski
**	Function Purpose: helper function for quicksort, swap two spots in the array
**		
**	Function Output: none
**	Side Effects: none
*/
void C_Binary::p_swap(employeeData *a, employeeData *b)
{
    employeeData t = *a;
    *a = *b;
    *b = t;
}

/*
**	Author: Evan Slominski
**	Function Purpose: create all 5 indexes in the array
**		
**	Function Output: none
**	Side Effects: none
*/
void C_Binary::p_indexArray( string sortedFileName, employeeData array[] ) {

    //open the sorted array file
    fstream sortedBinaryFile;
    sortedBinaryFile.open(sortedFileName, ios::in|ios::binary);

    //index the departments 0->4 inclusive
    for(int index=1; index<5; index++) {
        p_makeIndex(array, indexArray, index);
    }

    sortedBinaryFile.close();

}

/*
**	Author: Evan Slominski
**	Function Purpose: make the actual entry in the indexArray
**		
**	Function Output: none
**	Side Effects: none
*/
void C_Binary::p_makeIndex(employeeData array[], int indexArray[], int indexSpot) {
    int swap = 0;
    int i = 0;

     do{
        if( indexSpot <= array[i].department ) { 
            swap = array[i].department;
        } else {
            i++;
        }
    } while( swap == 0);

    i = i * (sizeof(char)*38);

    //set spot in array index
    this->indexArray[indexSpot] = i;

}

/*
**	Author: Evan Slominski
**	Function Purpose: get employees name
**		
**	Function Output: employee name/ user prompts
**	Side Effects: none
*/
void C_Binary::p_getEmployeeName( string fileName ) {

    //get info from user
    int departmentNum = -1;
    int employeeID = -1;

    cout<<"Enter employee department number: ";
    cin>>departmentNum;
    cout<<"Enter employee ID: ";
    cin>>employeeID;
    cout<<endl;

    //open the sorted array file
    fstream sortedBinaryFile;
    sortedBinaryFile.open(fileName, ios::in|ios::binary);
    sortedBinaryFile.seekg(ios::beg);

    //search file for it
    employeeData *searchingStruct = new employeeData;
    int flag = 0;
    sortedBinaryFile.seekg(ios::beg+this->indexArray[departmentNum]);
    while( flag == 0 )  {
            sortedBinaryFile.read((char*)searchingStruct, (sizeof(char)*38));
            if( searchingStruct->id == employeeID ) {
                flag = 1;
                cout << "the employees name is: " << searchingStruct->name << endl;
                cout << "department num: " << searchingStruct->department << endl;
                goto end;
            }
            if( searchingStruct->department != departmentNum ) {
                cout << "Cannot move outside index" << endl;
                goto end;
            }

            if( sortedBinaryFile.eof() ) {
                cout << "Cannot move outside index" << endl;
                goto end;
            }
    }
    end:

    sortedBinaryFile.close();
}

/*
**	Author: Evan Slominski
**	Function Purpose: change an employees name in the Sorted binary
**		
**	Function Output: user prompts
**	Side Effects: none
*/
void C_Binary::p_changeEmployeeName( string fileName ) {
       //get info from user
    int departmentNum = -1;
    int employeeID = -1;
    char newName[30];

    cout<<"Enter employee department number: ";
    cin>>departmentNum;
    cout<<flush;
    cout<<"Enter employee ID: ";
    cin>>employeeID;
        cout<<flush;

    cout<<"Enter the new name: ";
    cin >> newName;
        cout<<flush;


    
    //open the file
    fstream sortedBinaryFile;
    sortedBinaryFile.open(fileName, ios::in|ios::out|ios::binary);
    sortedBinaryFile.seekg(ios::beg);

    //search file for it
    employeeData *searchingStruct = new employeeData;
    int flag = 0;
    int pos;
    sortedBinaryFile.seekg(ios::beg+this->indexArray[departmentNum]);

    while( flag == 0) {
            pos = sortedBinaryFile.tellg();
            sortedBinaryFile.read((char*)searchingStruct, (sizeof(char)*38));
            if( searchingStruct->id == employeeID ) {
                flag = 1;
                //change the values to indicate that person doesn't exist
                searchingStruct->department = departmentNum;
                searchingStruct->id = employeeID;
                strncpy(searchingStruct->name, newName, sizeof(newName));
                cout<<endl;               
                sortedBinaryFile.seekp(pos); 
                sortedBinaryFile.write( (char*)searchingStruct, (sizeof(char)*38));
            }
            if( searchingStruct->department != departmentNum ) {
                cout << "Cannot move outside index" << endl;
                goto end2;
            }

            if( sortedBinaryFile.eof() ) {
                cout << "Cannot move outside index" << endl;
                goto end2;
            }
    }
    end2:

    sortedBinaryFile.close();
}

/*
**	Author: Evan Slominski
**	Function Purpose: delete a record from the Sorted binary
**		
**	Function Output: user prompts
**	Side Effects: none
*/
void C_Binary::p_deleteEmployee( string fileName ) {
    //get info from user
    int departmentNum = -1;
    int employeeID = -1;
    char newName[30];
    newName[1] = '\0';

    cout<<"Enter employee department number: ";
    cin>>departmentNum;
    cout<<"Enter employee ID: ";
    cin>>employeeID;
    
    //open the file
    fstream sortedBinaryFile;
    sortedBinaryFile.open(fileName, ios::in|ios::out|ios::binary);
    sortedBinaryFile.seekg(ios::beg);

    //search file for it
    employeeData *searchingStruct = new employeeData;
    int flag = 0;
    int pos;
    sortedBinaryFile.seekg(ios::beg+this->indexArray[departmentNum]);

    while( flag == 0) {
            pos = sortedBinaryFile.tellg();
            sortedBinaryFile.read((char*)searchingStruct, (sizeof(char)*38));
            if( searchingStruct->id == employeeID ) {
                flag = 1;
                //change the values to indicate that person doesn't exist
                searchingStruct->department = -1;
                searchingStruct->id = -1;
                strncpy(searchingStruct->name, newName, sizeof(newName));
                cout<<endl;               
                sortedBinaryFile.seekp(pos); 
                sortedBinaryFile.write( (char*)searchingStruct, (sizeof(char)*38));
            }
            if( searchingStruct->department != departmentNum ) {
                cout << "Cannot move outside index" << endl;
                goto end3;
            }

            if( sortedBinaryFile.eof() ) {
                cout << "Cannot move outside index" << endl;
                goto end3;
            }
    }
    end3:

    sortedBinaryFile.close();

}

/*
**	Author: Evan Slominski
**	Function Purpose: list employees by the index range
**		
**	Function Output: employees in that range / user prompts
**	Side Effects: none
*/
void C_Binary::p_listEmployeesByRange( string fileName ) {
//get info from user
    int departmentNum = -1;
    char departmentName[30];
    char accounting[30] = "Accounting";
    char business[30] = "Business";
    char humanResources[30] = "Human Resources";
    char sales[30] = "Sales";
    char production[30] = "Production";
    int calcualtedEmployees = 0;
    int fileStringLength = -1;

    struct stat sizeOfFile;
    fileStringLength = fileName.length();
    char file[ fileStringLength + 10];
    strncpy( file, fileName.c_str(), sizeof(fileName));
    stat(file, &sizeOfFile);
    int sizeInBytes = sizeOfFile.st_size;

    repeatDepartmentNum:
    cout<<"Enter employee department number: ";
    cin>>departmentNum;
    switch (departmentNum)
    {
    case 0:
        strncpy( departmentName, accounting, sizeof(accounting));
        calcualtedEmployees = indexArray[1] / (sizeof(char)*38);
        break;
    case 1:
        strncpy( departmentName, business, sizeof(business));
        calcualtedEmployees = (indexArray[2] - indexArray[1]) / (sizeof(char)*38);
        break;
    case 2:
        strncpy( departmentName, humanResources, sizeof(humanResources));
        calcualtedEmployees = (indexArray[3] - indexArray[2]) / (sizeof(char)*38);
        break;
    case 3:
        strncpy( departmentName, sales, sizeof(sales));
        calcualtedEmployees = (indexArray[4] - indexArray[3]) / (sizeof(char)*38);
        break;
    case 4:
        strncpy( departmentName, production, sizeof(production));
        calcualtedEmployees = (sizeInBytes - indexArray[4]) / (sizeof(char)*38);
        break;
    default:
        cout << "Enter a valid department Number"<<endl;
        goto repeatDepartmentNum;
        break;
    }

    cout<<"There are " << calcualtedEmployees << " employees in " << departmentName << endl ;

    //ask the range of employees they want
    int begin, end;
    cout << "You will now enter a range of employees you want to see:"<< endl;
    cout << "    " << "starting range: ";
    cin >> begin;
    cout << "    " << "ending range: ";
    cin >> end;
    cout << endl;

    //open the file
    fstream sortedBinaryFile;
    sortedBinaryFile.open(fileName, ios::in|ios::binary);
    sortedBinaryFile.seekg(ios::beg);

    //search file for it
    employeeData *searchingStruct = new employeeData;
    int flag = 0;
    int pos;
    int index = 0;
    int employeesTheyWant;


    //time to loop
    employeesTheyWant = end - begin;

    //set starting position
    begin = begin * (sizeof(char)*38);

    //go to start of their requested range
    sortedBinaryFile.seekg(ios::beg+this->indexArray[departmentNum]+begin);

    // end -1 because be work from 0-9 not 1-10
     while( index <= employeesTheyWant) {
        pos = sortedBinaryFile.tellg();
        sortedBinaryFile.read((char*)searchingStruct, (sizeof(char)*38));

        if( searchingStruct->department != departmentNum ) {
                cout << "Cannot move outside index" << endl;
                goto end4;
            }

            if( sortedBinaryFile.eof() ) {
                cout << "Cannot move outside index" << endl;
                goto end4;
            }
            
        cout << "department num: " << searchingStruct->department << endl;
        cout << "id num: " << searchingStruct->id << endl;
        cout << "name: " << searchingStruct->name << endl<<endl;

        index++;
    }
    end4:

    sortedBinaryFile.close();
}
 