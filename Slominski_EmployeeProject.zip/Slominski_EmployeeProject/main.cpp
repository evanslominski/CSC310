#include <iostream>
#include <fstream>
#include <string.h>
#include "records.h"
#include "customErrorClass.h"

using namespace std;

int main(int argc, char *argv[]){ 

    C_Binary binaryClass;

    try {

        binaryClass.readInSortAndWriteSortedFile( argc, argv );
        binaryClass.promptUser();

    } catch (MyException &e) {
        cout<<e.what()<<endl;
    }

    return 0;
}