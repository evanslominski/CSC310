#ifndef SORTING
#define SORTING

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

struct employeeData {
    int department;
    int id;
    char name[30];
};

class C_Binary{
    public:
    //GOOD
    void readInSortAndWriteSortedFile( int argc, char *argv[] );
    void promptUser();

    private:
    //GOOD
        int indexArray[5] = {0};
        string globalFileName;
        string globalSortedFileName;

        bool p_validateFile(int argc, char *argv[]);
        void p_readInSortAndWriteSortedFile( string );
        void p_quickSort( employeeData[], int, int);
        int p_partition( employeeData[], int, int);
        void p_swap( employeeData*, employeeData*);
        void p_indexArray( string, employeeData[] );
        void p_makeIndex( employeeData[], int[], int );
        void p_getEmployeeName( string);
        void p_changeEmployeeName( string );
        void p_deleteEmployee( string);
        void p_listEmployeesByRange( string );

};
#endif
