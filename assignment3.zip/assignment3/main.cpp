#include <iostream>
#include <fstream>
#include <string.h>
#include "customErrorClass.h"

using namespace std;

void swap(int* a, int* b)
{
    int t = *a;
    *a = *b;
    *b = t;
}
 
/* This function takes last element as pivot, places
the pivot element at its correct position in sorted
array, and places all smaller (smaller than pivot)
to left of pivot and all greater elements to right
of pivot */
int partition (int arr[], int low, int high)
{
    int pivot = arr[high]; // pivot
    int i = (low - 1); // Index of smaller element and indicates the right position of pivot found so far
 
    for (int j = low; j <= high - 1; j++)
    {
        // If current element is smaller than the pivot
        if (arr[j] < pivot)
        {
            i++; // increment index of smaller element
            swap(&arr[i], &arr[j]);
        }
    }
    swap(&arr[i + 1], &arr[high]);
    return (i + 1);
}

void quickSort(int arr[], int low, int high)
{
    if (low < high)
    {
        /* pi is partitioning index, arr[p] is now
        at right place */
        int pi = partition(arr, low, high);
 
        // Separately sort elements before
        // partition and after partition
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void printArray( int array[], int numOfNumbers ) {
    int i=0;
    int newLine = 1;
    
    for( i = 1; i <= numOfNumbers; i++ ) {
        if(newLine == 6) {
            newLine = 1;
            cout <<endl;
        }
        cout << array[i] << " ";
        newLine++;
    }
    cout<<endl;
}

int main(int argc, char *argv[]){

    cout<<"NOTE: array[0] is worthless and allow no new line chars in input file"<<endl<<endl;

    int myArray[2000000];
    int i=0;
    int newLine = 0;
    fstream inputNormalFile;
    string inputData;

    inputNormalFile.open("goodData.dat", ios::in);

    //reads in data from normal file and writes it to a binary file
    if( inputNormalFile.is_open() ) {
        while( !inputNormalFile.eof() ) {
           inputNormalFile >> myArray[i];
            i++;
        }
    } else {
        throw MyException("File isn't open");
    }
    inputNormalFile.close();

    //save size of file
    int numOfNumbers = i;
    cout<< "There are " << numOfNumbers << " numbers in the 'input.dat' file"<<endl;

    //quicksort
    quickSort( myArray, 0, numOfNumbers );

    //print out sorted array
    printArray( myArray, numOfNumbers );
    cout<<endl;

    //write array to a binary file
    int tmp = 0;
    fstream outputToBinaryFile;
    outputToBinaryFile.open("sorted_binaryFile.dat", ios::out|ios::binary);

    cout<<"Writing to 'sorted_binaryFile.dat' . . ."<<endl;

    for( i = 1; i <= numOfNumbers; i++ ) {

        tmp = myArray[i];
        cout << "Writing num: " << myArray[i] <<endl;
        outputToBinaryFile.write((char*)&tmp, sizeof(int));

    }
    outputToBinaryFile.close();

    //index the binary file 
    int swap = 0; 
    int indexArray[1000];
    i=1;
    fstream binaryFile;
    outputToBinaryFile.open("sorted_binaryFile.dat", ios::in|ios::binary);

    int indexer = 0;
    int indexArrayIncrementer = 0;
    do{
        if( myArray[i] >= indexer ) {
            indexArray[indexArrayIncrementer] = i * sizeof(int) - 4;
            indexer = indexer + 10;
            indexArrayIncrementer++;
        } else {
            i++;
        }
    } while( indexArrayIncrementer !=7 );

    printArray( indexArray, 5); //doesn't work completely for this since it doesnt print indexArray[0]
    cout<<endl;

    //print out specific number of an index
    cout<<"Printing out index . . ."<<endl;
    for( int a=0; a <6; a++ ) {
        outputToBinaryFile.seekg(ios::beg+(indexArray[a]));
        swap = 0;
        outputToBinaryFile.read((char*)&swap, sizeof(int));
        cout<< swap<<endl;
    }
    cout<<endl;

    //get user input
    int userInput1 = 0, userInput2 = 0;
    cout<<"Input index: ";
    cin>>userInput1;
    cout<<"Input offset: ";
    cin>>userInput2;

    //spit out the num at that spot
    outputToBinaryFile.seekg(ios::beg+(indexArray[userInput1])+(userInput2*sizeof(int)));
        swap = 0;
        outputToBinaryFile.read((char*)&swap, sizeof(int));
        cout << "The number at the index: " << userInput1 << " + offset " << userInput2 << " = " << swap <<endl;

    outputToBinaryFile.close();
       
    return 0;
}