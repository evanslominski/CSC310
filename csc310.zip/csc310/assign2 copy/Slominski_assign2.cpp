#include <iostream>
#include "bst.h"
#include "customErrorClass.h"

using namespace std;

int main(int argc, char *argv[]) {
	bst *tree;
	tree = new bst;
	int height = 0;

	try {

		tree->makeTree();
		tree->printTree();
		tree->sortTree();
		cout<<"---------------------------------------"<<endl;
		tree->printTree();

	} catch( MyException &e ){

		cout<<e.what()<<endl;

	}

	return 0;
}