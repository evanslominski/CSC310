#include <iostream>
#include <iomanip>
#include <fstream>
#include <cmath>
#include "bst.h"
#include "customErrorClass.h"

using namespace std;
/*
**	Author: Evan Slominski
**	Function Purpose: set the root to NULL
**		
**	Function Output: none
**	Side Effects: none
*/
bst::bst() {  
	this->root = NULL;
}
/*
**	Author: Evan Slominski
**	Function Purpose: nothing
**		
**	Function Output: none
**	Side Effects: none
*/
void bst::insertValue( int x ) {
	//did not see a reason to use this public function
}
/*
**	Author: Evan Slominski
**	Function Purpose: read in the input file and then
**	insert them into the bst	
**	Function Output: none
**	Side Effects: none
*/
void bst::makeTree() {
	//no exception handling necessary **note I did do
	//some exception handling in p_makeTree to make up
	//for this
	this->p_makeTree();
}

/*
**	Author: Evan Slominski
**	Function Purpose: find a node in the tree
**		
**	Function Output: a 1 or 0
**	Side Effects: none
*/
int bst::findNode( int val ) {
	if(val <0) {
		throw MyException("Please enter a valid number");
	} else {
		node *search;
		search = p_findNode( val, this->root );
		if (search != NULL)
			return 1;
		else
			return 0;
	}
}

/*
**	Author: Evan Slominski
**	Function Purpose: get the height/numNodes of tree
**		
**	Function Output: the height/numNodes of tree
**	Side Effects: none
*/
int bst::getHeight() {
	if(this->root == NULL) {
		throw MyException("There is no tree");
	} else {
		int ans;
		ans = p_getHeight(this->root);
		return ans;
	}
}
/*
**	Author: Evan Slominski
**	Function Purpose: call p_sortTree()
**		
**	Function Output: none
**	Side Effects: none
*/
void bst::sortTree() {
	if(this->root == NULL) {
		throw MyException("There is no tree to balance");
	} else {
		p_sortTree();
	}
}
/*
**	Author: Evan Slominski
**	Function Purpose: call p_printTree()
**		
**	Function Output: none
**	Side Effects: none
*/
void bst::printTree() {
	if(this->root == NULL) {
		throw MyException("There is no tree to print");
	} else {
		p_printTree(this->root, 2);	
	}
}
/*
**	Author: Evan Slominski
**	Function Purpose: call p_deleteTree()
**		
**	Function Output: none
**	Side Effects: none
*/
void bst::deleteTree() {
	if(this->root == NULL) {
		throw MyException("There is no tree to delete");
	} else {
		p_deleteTree(this->root);	
	}
}
//***************************************//
//************PRIVATE********************//
//***************************************//

/*
**	Author: Evan Slominski
**	Function Purpose: Insert a value into the tree
**		
**	Function Output: none
**	Side Effects: none
*/
void bst::p_insertValue( node *root, node *newNode, node *parent) {
	node *move;
	move = root;

	if( move->rchild == NULL && move->dat < newNode->dat) {
		move->rchild = newNode;
		move->rchild->parent = move;
		return;
	} else if(move->lchild == NULL && move->dat > newNode->dat) {
		move->lchild = newNode;
		move->lchild->parent = move;
		return;
	}
	if (move->dat > newNode->dat) {
		p_insertValue(move->lchild, newNode, move);
	} else {
		p_insertValue(move->rchild, newNode, move);
	}

}
/*
**	Author: Evan Slominski
**	Function Purpose: create the bst
**		
**	Function Output: none	
**	Side Effects: none
*/
void bst::p_makeTree() {
	int newNum = 0;

    ifstream data;
    data.open("assign.dat");

	if( !data.is_open()) {
		throw MyException("This file does not exist");
	} else {
    	while( !data.eof() ) {

    		data >> newNum;

			node *newNode;
			node *parent = NULL;

			newNode = new node();
			newNode->dat = newNum;
			newNode->lchild = NULL;
			newNode->rchild = NULL;

			if(this->root == NULL) {
				this->root = newNode;
				newNode->parent = NULL;
			} else {
				p_insertValue(this->root, newNode, parent);
			}     
    	}
    	data.close();
	}

}
/*
**	Author: Evan Slominski
**	Function Purpose: find a node in the bst
**		
**	Function Output: returns the node it found
**	Side Effects: none
*/
node *bst::p_findNode( int x, node *t){
	if(t == NULL)
		return NULL;
	if ( t->dat == x)
		return t;
	if (t->dat < x)
		return p_findNode(x, t->rchild);
	return p_findNode(x, t->lchild);
}
/*
**	Author: Evan Slominski
**	Function Purpose: get the height/numNodes of bst
**		
**	Function Output: returns height
**	Side Effects: none
*/
int bst::p_getHeight( node *t) {
	if(t == NULL)
		return 0;
	else
	{
		int l = p_getHeight(t->lchild);
		int r = p_getHeight(t->rchild);

		if(l > r) {
			return(l+1);
		} else {
			return(r+1);
		}
	}
}
/*
**	Author: Evan Slominski
**	Function Purpose: prints the tree
**		
**	Function Output: the printed tree
**	Side Effects: none
*/
void bst::p_printTree(node *node, int indent){
    if( NULL == node ){
        return;
    } else {
        this->p_printTree(node->lchild, indent+4);
        if( indent ){
            cout<<setw(indent)<<" ";
        }
        cout<<node->dat<<endl;
        this->p_printTree(node->rchild, indent+4);
    }
}
/*
**	Author: Evan Slominski
**	Function Purpose: delete the tree
**		
**	Function Output: none	
**	Side Effects: none
*/
void bst::p_deleteTree(node *root) {
	node *tmp = this->root;
	if(tmp == NULL ) {
		return;
	}
	p_deleteTree(tmp->lchild);
	p_deleteTree(tmp->rchild);
	if(tmp->lchild == NULL && tmp->rchild == NULL) {
		free(tmp);
		return;
	}
}
/*
**	Author: Evan Slominski
**	Function Purpose: create the vine in the bst
**		
**	Function Output: none
**	Side Effects: none
*/
void bst::p_createVine() {
    node * tmp = this->root; 
    while(tmp != NULL){ 
    	if( tmp->lchild !=NULL) {
			p_rotateRight(tmp->parent, tmp, tmp->lchild );
			tmp = tmp->parent;
		}
        else {
            tmp = tmp->rchild;
		}
     }
}	
/*
**	Author: Evan Slominski
**	Function Purpose: rotate right on a node
**		
**	Function Output: none
**	Side Effects: none
*/
void bst::p_rotateRight(node *GParent, node *Parent,node *Child) {
	//check if root needs update
	if(GParent == NULL ) {
		this->root = Child;
		if(Child->rchild != NULL) {
			Child->rchild->parent = Parent;
		}
		Parent->lchild = Child->rchild;
		Child->parent = Parent->parent;
		Parent->parent = Child;
		Child->rchild = Parent;
	} else {
		GParent->rchild = Child;
		Child->parent = GParent;
		Parent->parent = Child;	
		if(Child->rchild != NULL) {
			Child->rchild->parent = Parent;
		}
		Parent->lchild = Child->rchild;
		Child->rchild = Parent;
	}
}
/*
**	Author: Evan Slominski
**	Function Purpose: call p_createVine() and p_createTree()
**		
**	Function Output: none
**	Side Effects: none
*/
void bst::p_sortTree() {
	p_createVine();
	int height = getHeight();
	p_createTree(height);
}
/*
**	Author: Evan Slominski
**	Function Purpose: balance the tree/vine
**		
**	Function Output: none
**	Side Effects: none
*/
void bst::p_createTree(int numNodes) {
	int m = 0;
	int log = 0;
	int index = 0;
	node * tmp; 
	log = log2(numNodes + 1);
	m = pow(2, log) -1;
	//cout<<"Number of Nodes: "<<numNodes<<endl<<"Perfect height of tree: "<<log<<endl<<"Perfect number of nodes in a tree: "<<m<<endl;
    tmp = this->root->rchild;
	//balancing of m-n
	for(index=0; index<(numNodes-m);index++) {
		p_rotateLeft(tmp->parent, tmp, tmp->rchild);
		tmp = tmp->rchild->rchild;
	}
	
    while (m > 1) { //tree has not attained a balanced state 
        m = m/2;
		tmp = this->root->rchild;
		for(index = 0; index<m; index++) {
			p_rotateLeft(tmp->parent,tmp, tmp->rchild);
			tmp = tmp->rchild->rchild;
		}
	}   
	
}
/*
**	Author: Evan Slominski
**	Function Purpose: rotate left on a node
**		
**	Function Output: none
**	Side Effects: none
*/
void bst::p_rotateLeft(node *GParent, node *Parent, node *Child ) {
	
	if(GParent->parent == NULL) {
		this->root = Parent;
		GParent->rchild = Parent->lchild;
		Parent->parent = GParent->parent;
		
		GParent->parent = Parent;
		Parent->lchild = GParent;
	} else { //GParent->parent->parent == NULL

		GParent->parent->rchild = Parent;
		Parent->parent = GParent->parent;
		GParent->rchild = Parent->lchild;
		Parent->lchild = GParent;
		GParent->parent = Parent;
	}

}