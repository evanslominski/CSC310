#ifndef BST
#define BST

#include <iostream>
#include <string>

using namespace std;

struct node {
	int dat;
	node *lchild;
	node *rchild;
	node *parent; //add maybe?
};

class bst
{
	public:
		bst();					   //GOOD				   //GOOD
		void insertValue( int x ); //GOOD
		void makeTree();	       //GOOD
		int findNode( int val );   //GOOD
		int getHeight();           //GOOD
		void sortTree();	 	   //add	
		void printTree();          //GOOD
		void deleteTree();	 	   //meh

	private:
		node * root;
		void p_insertValue( node *, node * , node *); //GOOD
		void p_makeTree();						//GOOD
		node *p_findNode( int x, node *t );		//GOOD
		int  p_getHeight( node *t );			//GOOD
		void p_sortTree();	 					//GOOD	
		void p_printTree(node *t, int x);		//GOOD
		void p_deleteTree(node *t); 			//
		void p_createVine(); 	 				//GOOD
		void p_rotateRight(node *GParent, node *Parent, node *Child);	 //GOOD
		void p_rotateLeft(node *, node *, node *);     //GOOD
		void p_createTree(int);	 				//GOOD
};
#endif