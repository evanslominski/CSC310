#include <iostream>
#include <iomanip>
#include <fstream>
#include <sys/stat.h>
#include <cerrno>
#include <cstring>
#include "functions.h"
#include "customErrorClass.h"

using namespace std;

/*
**	Author: Evan Slominski
**	Function Purpose: constructor
**		
**	Function Output: none
**	Side Effects: none
*/
C_rbTree::C_rbTree() {
    this->root = NULL;
}

/*
**	Author: Evan Slominski
**	Function Purpose: destructor    
**		
**	Function Output: none
**	Side Effects: none
*/
C_rbTree::~C_rbTree() {
    p_deleteTree(this->root);
}

/*
**	Author: Evan Slominski
**	Function Purpose: calling p_readInFile()
**		
**	Function Output: none
**	Side Effects: none
*/
void C_rbTree::readInFile( int argc, char* argv[]) {
    //exception handling done in private function
    p_readInFile( argc, argv);
}

/*
**	Author: Evan Slominski
**	Function Purpose: call p_insertValue() & except handling
**		
**	Function Output: none
**	Side Effects: none
*/
void C_rbTree::insertValue( int val ) {
    if(val < 0 ) {
        throw MyException("Values entered must be greater than or equal to 0");
    } else {
        p_insertNode( val );
    }
}

/*
**	Author: Evan Slominski
**	Function Purpose: call p_deleteNode() & except handling
**		
**	Function Output: none
**	Side Effects: none
*/
void C_rbTree::deleteNode( int val ) {
    if(val < 0 ) {
        throw MyException("Values lower than 0 cannot be deleted from tree since they don't exist");
    } else {
        p_deleteNode( val );
    }
}

/*
**	Author: Evan Slominski
**	Function Purpose: call p_printTree and except handling
**		
**	Function Output: none
**	Side Effects: none
*/
void C_rbTree::printTree() {
    if(this->root == NULL ) {
        throw MyException("Cannot print a tree that doesnt exist");
    } else {
        p_printTree( this->root, 2);
    }
}

/*
**	Author: Evan Slominski
**	Function Purpose: call p_deleteTree & except handling
**		
**	Function Output: none
**	Side Effects: none
*/
void C_rbTree::deleteTree() {
    if(this->root == NULL ) {
        throw MyException("Cannot delete a tree that doesnt exist");
    } else {
        p_deleteTree(this->root);
        this->root = NULL;
    }
}

/*************PRIVATE*****************/
/*
**	Author: Evan Slominski
**	Function Purpose: read in the file
**		
**	Function Output: none
**	Side Effects: none
*/
void C_rbTree::p_readInFile( int argc, char *argv[]) {
    int exitflag = 0;
    bool retValue = false;
    int num1 = 9999, num2 = 9999;

    retValue = p_validateFile(argc, argv);
    
    ifstream data;
    data.open(argv[1]);

    data >> num1;
    if(num1 == 0 || num1 == 1) {
        data >> num2;
    }
    
    while( !data.eof() ) {
        switch(num1) { 
		    case 0:
            //insert
                if(p_searchForValue( num2, this->root ) == 0) {
                    insertValue( num2 );
                } else {
                    throw MyException("Cannot insert the same value twice");
                }
                break;
		    case 1 :
		    //delete
                if(p_searchForValue( num2, this->root ) == 1) {
                    deleteNode( num2 );
                } else {
                    throw MyException("Cannot delete a that doesn't exist");
                }

		    	break;
		    case 2 :
            //print tree to screen
                printTree();
		    	break;
		    case 8 :
            //delete the tree	
                exitflag = 1;
                deleteTree();
		    	break;
		    case 9 :
            //stop reading from file and quit the program
                if(exitflag == 1) {
                    p_stopReadingFile();
                } else {
                    throw MyException("Cannot exit since you did not delete the tree first");
                }
		    	break;
		    default :
		    //catch the junk nums
                break;
        }
        data >> num1;
        if(num1 == 0 || num1 == 1) {
            data >> num2;
        }
    }
    data.close();
}

/*
**	Author: Evan Slominski
**	Function Purpose: Validate the file and return true or false
**		
**	Function Output: none
**	Side Effects: none
*/
bool C_rbTree::p_validateFile(int argc, char *argv[]) {
    int error = 0;
    bool retValue = false;
    string errorString;
    struct stat fileValidation;
    char * file = argv[1];

    //check if file exists
    if( 1 >= argc || 3 <= argc) {
        string firstArg = argv[0];
        throw MyException("USAGE: " + firstArg + " [FILENAME]");
        cout<<"exiting..."<<endl;
    } else {
        error = stat(file, &fileValidation);

        if( 0 != error ) {
            errorString = strerror(errno);
            errorString += ": ";
            errorString += argv[1];
            throw runtime_error(errorString);
        }

        if(fileValidation.st_size == 0) {
            errorString = "File is empty: ";
            errorString += argv[1];
            throw runtime_error(errorString);
        }

        retValue = true;
    }
    return retValue;
}

/*
**	Author: Evan Slominski
**	Function Purpose: insert a value into the tree and add a value recursively if need be
**		
**	Function Output: none
**	Side Effects: none
*/
void C_rbTree::p_insertNode( int val ) {
    //print out num inserted
    //cout<<"Insert the number: "<<val<<endl;

    //Create new nodes
    struct node *newNodeHead = new node();
    struct node *newNodeLeft = new node();
    struct node *newNodeRight = new node();

    //set default values for LEFT and RIGHT nodes
    newNodeLeft->color = 0;
    newNodeLeft->dat = -1;
    newNodeLeft->lchild = NULL;
    newNodeLeft->rchild = NULL;
    newNodeLeft->parent = newNodeHead;

    newNodeRight->color = 0;
    newNodeRight->dat = -1;
    newNodeRight->lchild = NULL;
    newNodeRight->rchild = NULL;
    newNodeRight->parent = newNodeHead;

    //set default values for "Head" node
    newNodeHead->color = 1;
    newNodeHead->dat = val;
    newNodeHead->lchild = newNodeLeft;
    newNodeHead->rchild = newNodeRight;
    newNodeHead->parent = NULL;
    
    //insert into tree
    if(this->root == NULL) {
        this->root = newNodeHead;
        newNodeHead->parent = NULL;
        newNodeHead->color = 0;
    } else {
        p_insertNodeRecursive( this->root, newNodeHead);
    }
}

/*
**	Author: Evan Slominski
**	Function Purpose: insert a node that isn't the root node
**		
**	Function Output: none
**	Side Effects: none
*/
void C_rbTree::p_insertNodeRecursive( node* localRoot, node* newNode) {

    //check which way to go
    if( localRoot->dat < newNode->dat ) {

        if( localRoot->rchild->dat == -1 ) {
            free(localRoot->rchild);
            localRoot->rchild = newNode;
            newNode->parent = localRoot;
            p_validateInsertion( newNode );
        } else {
            p_insertNodeRecursive( localRoot->rchild, newNode );
        }

    } else if( localRoot->dat > newNode->dat ) {

        if( localRoot->lchild->dat == -1 ) {
            free(localRoot->lchild);
            localRoot->lchild = newNode;
            newNode->parent = localRoot;
            p_validateInsertion( newNode );
        } else {
            p_insertNodeRecursive( localRoot->lchild, newNode );
        }

    }
}

/*
**	Author: Evan Slominski
**	Function Purpose: Validate and balance the tree using RBTREE principals
**		
**	Function Output: 
**	Side Effects: 
*/
void C_rbTree::p_validateInsertion( node* ptr ) {

    //while not root, ptr not black, and parent is red
    while( (ptr != root) && (ptr->color != 0) && (ptr->parent->color == 1) ) {
        node * parent = ptr->parent;
        node * Gparent = ptr->parent->parent;
        node * uncle = NULL;
        //if parent is Gparent's lchild
        if( parent == Gparent->lchild ) {

            //get uncle
            uncle = p_getUncle( 1, ptr );

            //Case 3 just change colors
            if( uncle != NULL && uncle->color == 1 ) {

                parent->color = 0;
                uncle->color = 0;
                Gparent->color = 1;
                ptr = Gparent;

            } else {
            
            //Case 4 rotation
                //if ptr is a rchild of parent LROTATE to straighten ->rotate on P
                if( ptr == parent->rchild ) {
                    p_leftRotate( parent );
                    ptr = parent;
                    parent = ptr->parent;
                    //cout<<"Node is rchild of parent"<<endl;
                }

                //ptr is lchild of parent RROTATE needed ->rotate on GP
                p_rightRotate( Gparent );
                //some color stuff
                ptr->parent->color = 0;
                ptr->parent->rchild->color = 1;

                ptr = parent;

            }

        } else {
          // parent is Gparent's rchild  

            //get uncle
            uncle = p_getUncle( 0, ptr );

            //Case 3 just change colors
            if( uncle != NULL && uncle->color == 1 ) {

                parent->color = 0;
                uncle->color = 0;
                Gparent->color = 1;
                ptr = Gparent;

            } else {
            
            //Case 4 rotation
           //if ptr is a lchild of parent RROTATE to straighten ->rotate on P
                if( ptr == parent->lchild ) {
                    p_rightRotate( parent );
                    ptr = parent;
                    parent = ptr->parent;
                    //cout<<"Node is lchild of parent"<<endl;
                }

            //ptr is rchild of parent LROTATE needed ->rotate on GP
                p_leftRotate( Gparent );
                //some color stuff
                ptr->parent->color = 0;
                ptr->parent->lchild->color = 1;
                
                ptr = parent;

            }
        }
    }
    root->color = 0;
}

/*
**	Author: Evan Slominski
**	Function Purpose: get the uncle node used to validate RBtree
**		
**	Function Output: none
**	Side Effects: none
*/
node * C_rbTree::p_getUncle( int rightORleft, node* ptr ) {

    node * uncle = NULL;

        if( rightORleft == 1 ) {

            uncle = ptr->parent->parent->rchild;
            return uncle;

        } else {

            uncle = ptr->parent->parent->lchild;
            return uncle;

        }
}

/*
**	Author: Evan Slominski
**	Function Purpose: rotate right on the parent
**		
**	Function Output: none
**	Side Effects: none
*/
void C_rbTree::p_rightRotate( node*Parent ) {
    node *ptrChild = Parent->lchild;
    //cout<<"ROTATING ON"<<Parent->parent->dat<<endl;

   //easier to do this way ^^ instead of changing variable in the validation
   //function and destroing the child variable
    Parent->lchild = ptrChild->rchild;
  
    if (Parent->lchild != NULL)
        Parent->lchild->parent = Parent;
  
    ptrChild->parent = Parent->parent;
  
    //check if root node
    if (Parent->parent == NULL)
        root = ptrChild;
  
    else if (Parent == Parent->parent->lchild)
        Parent->parent->lchild = ptrChild;
  
    else
        Parent->parent->rchild = ptrChild;
  
    ptrChild->rchild = Parent;
    Parent->parent = ptrChild;
}

/*
**	Author: Evan Slominski
**	Function Purpose: rotate left on the parent node
**		
**	Function Output: none
**	Side Effects: none
*/
void C_rbTree::p_leftRotate( node*Parent ) {
    node *ptrChild = Parent->rchild;
    //cout<<"ROTATING ON"<<Parent->parent->dat<<endl;
    //easier to do this way ^^ instead of changing variable in the validation
    //function and destroing the child variable
    Parent->rchild = ptrChild->lchild;
  
    if (Parent->rchild != NULL)
        Parent->rchild->parent = Parent;
  
    ptrChild->parent = Parent->parent;
  
    //check for root node
    if (Parent->parent == NULL)
        root = ptrChild;
  
    else if (Parent == Parent->parent->rchild)
        Parent->parent->rchild = ptrChild;
  
    else
        Parent->parent->lchild = ptrChild;
  
    ptrChild->lchild = Parent;
    Parent->parent = ptrChild;
}

/*
**	Author: Evan Slominski
**	Function Purpose: search for a value in the tree and return a 1 if it was found
**		
**	Function Output: none
**	Side Effects: none
*/
int C_rbTree::p_searchForValue( int val, node *node ) {

    //return 0 if not found
    if(node == NULL) {
        return 0;
    }
    //return 1 if value found
	if ( node->dat == val) {
        return 1;
    }
    //move to next spot in bst tree
	if (node->dat < val) {
        return p_searchForValue(val, node->rchild);
    }

	return p_searchForValue(val, node->lchild);

}

/*
**	Author: Evan Slominski
**	Function Purpose: Delete the tree recursively
**		
**	Function Output: none
**	Side Effects: removes tree
*/
void C_rbTree::p_deleteTree(node * node) {
    if (node == NULL) return;
  
    //delete tree using a post order traversal
    p_deleteTree(node->lchild);
    p_deleteTree(node->rchild);
    
    //cout<<"Deleting node "<<node->dat<<endl;

    
    delete node;
}

/*
**	Author: Evan Slominski
**	Function Purpose: Stop reading from the file
**		
**	Function Output: none
**	Side Effects: none
*/
void C_rbTree::p_stopReadingFile() {
    exit(0);
}

/*
**	Author: Evan Slominski & Alex Wollman
**	Function Purpose: prints the tree
**		
**	Function Output: the printed tree
**	Side Effects: red nodes are red and black nodes are black
*/
void C_rbTree::p_printTree(node *node, int indent){

    if( node->dat == -1 ){
        return;
    } else {
        this->p_printTree(node->lchild, indent+4);
        if( indent ){
            cout<<setw(indent)<<" ";
        }
        //color code the tree
        if(node->color == 1) {
            cout<< "\e[31;1m" << node->dat<< "\e[0m" <<endl;
        } else {
            cout<<node->dat<<endl;

        }
        
        this->p_printTree(node->rchild, indent+4);
    }
}

/*
**	Author: Evan Slominski
**	Function Purpose: return a node based on the value passses in
**		
**	Function Output: none
**	Side Effects: none
*/
node* C_rbTree::p_returnNodeInTree( int val, node *ptr ) {

    node* valueFound = NULL;
    //return NULL node if not found
    if( ptr == NULL ) {
        return valueFound;
    }
    //return ptr to actual node if found
	if ( ptr->dat == val ) {
        valueFound = ptr;
        return valueFound;
    }
    //move to the right in tree bst if val greater
	if ( ptr->dat < val ) {
        return p_returnNodeInTree( val, ptr->rchild );
    }
    //move to the left in tree bst if val less than
	return p_returnNodeInTree( val, ptr->lchild );

}

/*
**	Author: Evan Slominski
**	Function Purpose: Delete a value from the tree
**		
**	Function Output: none
**	Side Effects: changes the tree
*/
void C_rbTree::p_deleteNode( int val ) {

    node * deleteNodePtr = NULL;
    node * problemNode = NULL;
    node * successor = NULL;

    //get node that needs to be deleted
    deleteNodePtr =p_returnNodeInTree( val, this->root );

    successor = deleteNodePtr;
    //get the original value of node being "deleted(kind of)"
    //this may change if a we have to swap values with sucessor
    int originalColorOfNode = successor->color;    
    if( deleteNodePtr->rchild->dat == -1 ) {
        //check if right child  is NIL
        problemNode = deleteNodePtr->lchild;
        p_swapNodes( deleteNodePtr, deleteNodePtr->lchild );
    } else if ( deleteNodePtr->lchild->dat == -1 ) {
        //check if left child is NIL
        problemNode = deleteNodePtr->rchild;
        p_swapNodes( deleteNodePtr, deleteNodePtr->rchild);
    } else {
        //if node to be deleted has two actual child nodes
        //can't 
        successor = p_getSuccessor( deleteNodePtr->rchild );
        originalColorOfNode = successor->color;
        problemNode = successor->rchild;
        if( successor->parent == deleteNodePtr ) {
            problemNode->parent = successor;
        } else {
            //root node
            p_swapNodes( successor, successor->rchild );
            successor->rchild = deleteNodePtr->rchild;
            successor->rchild->parent = successor;

        }
        p_swapNodes( deleteNodePtr, successor );
        successor->lchild = deleteNodePtr->lchild;
        successor->lchild->parent = successor;
        successor->color = deleteNodePtr->color;
    }
        
    delete deleteNodePtr;

    //if db situation
    if(originalColorOfNode == 0 ) {
        p_fixDeletion( problemNode );
    }
}

/*
**	Author: Evan Slominski
**	Function Purpose: swap two nodes so we can delete a leaf node
**		
**	Function Output: none
**	Side Effects: changes trees colors
*/
void C_rbTree::p_swapNodes( node * original, node * replacement ) {

    //swap between two codes
    if( original->parent == NULL ) {
        //swapping on the root node
        this->root = replacement;
         replacement->parent = original->parent;
    } else if( original == original->parent->lchild ) {
        //if original = leftchild of parent
        original->parent->lchild = replacement;
         replacement->parent = original->parent;
    } else {
        //if original = rightchild of parent
        original->parent->rchild = replacement;
         replacement->parent = original->parent;
    }
}

/*
**	Author: Evan Slominski
**	Function Purpose: get the successor of the node passed to it and return a ptr
**		
**	Function Output: none
**	Side Effects: none
*/
node* C_rbTree::p_getSuccessor( node * ptr ) {
    // continue moving as far left until you reach a node of -1
    while ( ptr->lchild->dat != -1 ) {
        //move to lchild
		ptr = ptr->lchild;
	}
	
    return ptr; 
}

/*
**	Author: Evan Slominski
**	Function Purpose: fix the tree after a deletion occurs; double black is addresses here
**		
**	Function Output: none
**	Side Effects: changes the tree
*/
void C_rbTree::p_fixDeletion( node *problemNode ) {

    node * siblingNode;
		while (problemNode != root && problemNode->color == 0) {
			if (problemNode == problemNode->parent->lchild) {
				siblingNode = problemNode->parent->rchild;
				if (siblingNode->color == 1) {
					// problemNode's siblingNode is red
					siblingNode->color = 0;
					problemNode->parent->color = 1;
					p_leftRotate(problemNode->parent);
					siblingNode = problemNode->parent->rchild;
				}

				if (siblingNode->lchild->color == 0 && siblingNode->rchild->color == 0) {
					// problemNode's siblingNode is black and both of its child nodes are black
					siblingNode->color = 1;
					problemNode = problemNode->parent;
				} else {
					if (siblingNode->rchild->color == 0) {
						// problemNodes's siblingNode is black and siblingNode's closest child is red
						siblingNode->lchild->color = 0;
						siblingNode->color = 1;
						p_rightRotate(siblingNode);
						siblingNode = problemNode->parent->rchild;
					} 

					// problemNodes's siblingNode is black and siblingNode's farthest child is red
					siblingNode->color = problemNode->parent->color;
					problemNode->parent->color = 0;
					siblingNode->rchild->color = 0;
					p_leftRotate(problemNode->parent);
					problemNode = root;
				}
			} else {
				siblingNode = problemNode->parent->lchild;
				if (siblingNode->color == 1) {
					// problemNode's siblingNode is red
					siblingNode->color = 0;
					problemNode->parent->color = 1;
					p_rightRotate(problemNode->parent);
					siblingNode = problemNode->parent->lchild;
				}

				if (siblingNode->rchild->color == 0 && siblingNode->rchild->color == 0) {
					// problemNode's siblingNode is black and both of its child nodes are black
					siblingNode->color = 1;
					problemNode = problemNode->parent;
				} else {
					if (siblingNode->lchild->color == 0) {
						// problemNodes's siblingNode is black and siblingNode's closest child is red
						siblingNode->rchild->color = 0;
						siblingNode->color = 1;
						p_leftRotate(siblingNode);
						siblingNode = problemNode->parent->lchild;
					} 

					// problemNodes's siblingNode is black and siblingNode's farthest child is red
					siblingNode->color = problemNode->parent->color;
					problemNode->parent->color = 0;
					siblingNode->lchild->color = 0;
					p_rightRotate(problemNode->parent);
					problemNode = root;
				}
			} 
		}
        //satisfy color requirements
		problemNode->color = 0;
}