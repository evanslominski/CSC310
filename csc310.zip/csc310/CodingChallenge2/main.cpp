#include <iostream>
#include "functions.h"
#include "customErrorClass.h"

using namespace std;

int main(int argc, char *argv[]) {
	
    C_rbTree tree;

	try {
        tree.readInFile(argc, argv);
	} catch(runtime_error &e) {
		cout<<"RUNTIME_ERROR: "<<e.what()<<endl;
	} catch( MyException &e ){
		cout<<"EXCEPTION: "<<e.what()<<endl;
	}

	return 0;
}
