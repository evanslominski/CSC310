#ifndef BST
#define BST

#include <iostream>
#include <string>

using namespace std;

struct node {
	int dat;
    int color;  //red=1 black=0
	node *lchild;
	node *rchild;
	node *parent;
};

class C_rbTree
{
	public:
		C_rbTree();
        ~C_rbTree();
        void readInFile(int, char *[]);
		void insertValue( int );
        void deleteNode( int );
        void printTree();
        void deleteTree(); 	      
		
	private:
		node * root;
        void p_readInFile(int, char *[]);
        bool p_validateFile(int, char *[]);
        void p_insertNode( int );
        void p_insertNodeRecursive( node *, node *);
        void p_validateInsertion(node *);
        node* p_getUncle( int , node* ptr );
        void p_rightRotate( node* );
        void p_leftRotate( node* );
        int p_searchForValue( int, node*);
        void p_deleteTree(node* );
        void p_stopReadingFile();
        void p_printTree( node *, int ); //GOOD

        //deletion class
        void p_deleteNode( int ); //GOOD
        node* p_returnNodeInTree( int , node* ); //GOOD
        void p_swapNodes( node *, node * ); //GOOD
        void p_fixDeletion( node * );
        node* p_getSuccessor( node* ); //GOOD
};
#endif
