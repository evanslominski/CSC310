#include "unionFind.h"        
#include "customErrorClass.h"   
        
C_unionFind::C_unionFind() {
    this->p_dataArray = NULL;
    this->p_arraySize = 0;
}

C_unionFind::~C_unionFind() {
    delete[] this->p_dataArray;
}

void C_unionFind::initArray(int userArraySize){
	if (NULL != this->p_dataArray) {
        throw MyException("WARNING: Cannot initialize array twice; not re-initializing");
    } else {
        this->p_initArray(userArraySize);
    }
}

void C_unionFind::unionNumbers(int num1, int num2){
    int retValue = 0;

    retValue = this->p_verifyRange(num1, num2);

    /*
    TODO: Provide granularity in which number does not meet the range requirements
    */

    if( 0 != retValue ) {
        throw MyException("ERROR: Provided value is not in range of array");
    } else {
        this->p_unionNumbers(num1, num2);
    }
	
}

void C_unionFind::isConnected(int num1, int num2){
	int retValue = 0;
    bool verifyConnection = false;

    retValue = this->p_verifyRange(num1, num2);

    /*
    TODO: Provide granularity in which number does not meet the range requirements
    */

    if( 0 != retValue ) {
        throw MyException("ERROR: Provided value is not in range of array");
    } else {
        verifyConnection = this->p_isConnected(num1, num2);

        if(verifyConnection ) {
            cout<<"num1"<<" and "<<num2<<" are: CONNECTED"<<endl;
        } else {
            cout<<"num1"<<" and "<<num2<<" are: NOT CONNECTED"<<endl;

        }
    }
}

void C_unionFind::printArray(){
	if(NULL == p_dataArray ) {
        throw MyException("WARNING: No array to print");
    } else {
        this->p_printArray();
    }
}

//******************************//
//**********PRIVATE*************//
void C_unionFind::p_initArray(int userArraySize){
	if( 0 > userArraySize ) {
        throw MyException("ERROR: Cannot create array with a size of 0");
    } else {
        this->p_dataArray = new int[userArraySize];
        this->p_arraySize = userArraySize;

        int index = 0;
        for(index; index < this->p_arraySize; index++) {
            this->p_dataArray[index] = index;
        }
    }

}

void C_unionFind::p_unionNumbers(int num1, int num2){
    int index = 0;

    for(index = 0; index < this->p_arraySize; index++) {
        if( this->p_dataArray[index] == num1) {
            this->p_dataArray[index] = num2;
            //connected INDEX to num2
        }
    }
    
    
}

bool C_unionFind::p_isConnected(int num1, int num2){
	bool connectionVerified = false;
    
    if(this->p_dataArray[num1] == num2) {
        connectionVerified = true;
    }

    return connectionVerified;

}

void C_unionFind::p_printArray(){
	int index = 0;

    for(index; index < this->p_arraySize; index++) {
        cout<<"Array["<<index<<"] = "<<this->p_dataArray[index]<<endl;
    }
    cout<<endl;
}
 
int C_unionFind::p_verifyRange(int num1, int num2) {
    int retValue = -1; // negative 1 is a failure condition
    
    if(num1 < this->p_arraySize ) {
        if( num2 < this->p_arraySize ) {
            retValue = 0; // zero is a sucess condition
        } 
    } 
    return retValue;
}