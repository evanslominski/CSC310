#include "unionFind.h"
#include "customErrorClass.h"
#include <iostream>

using namespace std;

int main(int argc, char *argv[]){

    C_unionFind myClass;

    //should we include 1 big try catch for whole program?
        //why or why not
        //-wrap whole thing and bail in one spot, or you can
        //try them all indiviually to catch the exact error(this is very cumbersome)
    try {
        myClass.initArray(10);
        myClass.printArray();
        myClass.unionNumbers(9,4);
        myClass.unionNumbers(4,2);
        myClass.printArray();
        myClass.isConnected(9,2);
    } catch (MyException &e){
        cout<<e.what()<<endl;
    }
    



    return 0;
} 