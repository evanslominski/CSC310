#include <iostream>

using namespace std;

int main(int argc, char *argv[]){

    cout<<"I think this actualy works!!!"<<endl;

    return 0;
}