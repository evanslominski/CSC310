#include <iostream>
#include <iomanip>
#include <fstream>
#include "bst.h"
#include "customErrorClass.h"

using namespace std;

bst::bst() {  
	root = NULL;
}

void bst::in()
{
	in(root);
}

void bst::in(node * t)
{
	if ( t == NULL )
		 return;

	in(t->lchild);
	printf("%2d ", t->dat);
	in(t->rchild);
}

void bst::insertValue( int x ) {
	node *t1;

	t1 = new node();
	t1->dat = x;
	t1->lchild = NULL;
	t1->rchild = NULL;

	// for you
	if( root == NULL )
	{
		root = t1;
	}
	else
		p_insertValue(root, t1);
}

void bst::makeTree() {
	this->p_makeTree();
}

int bst::findNode( int val ) {
	node *search;
	search = p_findNode( val, root );
	if (search != NULL)
		return 1;
	else
		return 0;
}

int bst::getHeight() {
	int ans;
	ans = p_getHeight(*root);
	cout << ans;
	return 0;
}

void bst::sortTree() {

}

void bst::printTree() {
	p_printTree(root, 2);
}

void bst::deleteTree() {
	p_deleteTree(this->root);
}
//***************************************//
//************PRIVATE********************//
//***************************************//

void bst::p_insertValue( node *t, node *n ) {
	// for you
	if( t == NULL)
		t = n;

	if( t->dat < n->dat) {
		if ( t->rchild == NULL )
			t->rchild = n;
		else
			p_insertValue(t->rchild, n);
	} else if( t->dat > n->dat ) {
		if ( t->lchild == NULL )
			t->lchild = n;
		else
			p_insertValue(t->lchild, n);
		}
}

void bst::p_makeTree() {
	int newNum = 0;

    ifstream data;
    data.open("test.dat");

    while( !data.eof() ) {

    	data >> newNum;
		node *t1;

		t1 = new node();
		t1->dat = newNum;
		t1->lchild = NULL;
		t1->rchild = NULL;

		// for you
		if( root == NULL )
		{
			root = t1;
		}
		else
			p_insertValue(root, t1);
        
    }
    data.close();
}
node *bst::p_findNode( int x, node *t){
	if(t == NULL)
		return NULL;
	if ( t->dat == x)
		return t;
	if (t->dat < x)
		return p_findNode(x, t->rchild);
	return p_findNode(x, t->lchild);
}

int bst::p_getHeight( node t) {
	//cout<<"TACOS";
	if(root == NULL)
		return -1;
	else
	{
		int ldep = p_getHeight(*root->lchild);
		int rdep = p_getHeight(*root->rchild);

		if(ldep > rdep) {
			cout<< ldep;
			return(ldep+1);
		} else {
			cout<< rdep;
			return(rdep+1);
		}
	}
}

void bst::p_sortTree() {

}

void bst::p_printTree(node *node, int indent){
    if( NULL == node ){
        return;
    } else {
        this->p_printTree(node->lchild, indent+4);
        if( indent ){
            cout<<setw(indent)<<" ";
        }
        cout<<node->dat<<endl;
        this->p_printTree(node->rchild, indent+4);
    }
}

void bst::p_deleteTree(node *root) {
	node *tmp = this->root;
	if(tmp == NULL ) {
		return;
	}
	p_deleteTree(tmp->lchild);
	p_deleteTree(tmp->rchild);
	if(tmp->lchild == NULL && tmp->rchild == NULL) {
		free(tmp);
		return;
	}
}

void bst::p_createVine() {

}	

void bst::p_rotateRight() {
	//rotating on the parent
  	/*GP->RChild = Child
  	parent->parent = Child;

  	if( Parent-> LChild != NULL) {
    	Parent->LChild = Child->RChild;
  	}

  	Child->Parent = GParent;
  	Child->RChild = Parent;
	*/

	node *TMP = root;
	node *GP = NULL;

}

void bst::p_rotateLeft() {

}

void bst::p_createTree() {

}