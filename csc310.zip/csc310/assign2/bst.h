#ifndef BST
#define BST

#include <iostream>
#include <string>

using namespace std;

struct node {
	int dat;
	node *lchild;
	node *rchild;
	node *parent; //add maybe?
};

class bst
{
	public:
		bst();					   //GOOD
		void in();				   //GOOD
		void insertValue( int x ); //GOOD
		void makeTree();	       //GOOD
		int findNode( int val );   //GOOD
		int getHeight();           //SEGMENTATION FAULT
		void sortTree();	 	   //add	
		void printTree();          //GOOD
		void deleteTree();	 	   //SEGMENTATION FAULT
		

	private:
		node * root;
		void p_insertValue( node *t, node *n ); //GOOD
		void in( node *t);						//GOOD
		void p_makeTree();						//GOOD
		node *p_findNode( int x, node *t );		//GOOD
		int  p_getHeight( node t );				//SEGMENTATION FAULT
		void p_sortTree();	 					//add	
		void p_printTree(node *t, int x);		//GOOD
		void p_deleteTree(node *t); 			//SEGMENTATION FAULT

		void p_createVine(); 	 //add
		void p_rotateRight();	 //add
		void p_rotateLeft();     //add
		void p_createTree();	 //add
};
#endif